# Release APK protection. Android entry points retain their manifest names; internal code is obfuscated.
-keep public class com.example.keywordsmsforwarder.MainActivity { public <init>(); }
-keep public class com.example.keywordsmsforwarder.SmsReceiver { public <init>(); }
-keep public class com.example.keywordsmsforwarder.MessageNotificationListener { public <init>(); }
-keepclassmembers class **.R$* { public static <fields>; }
# Custom views referenced by fully-qualified class name from XML must keep their names.
-keep public class com.example.keywordsmsforwarder.TagInputView {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
}
-keep public class com.example.keywordsmsforwarder.FlowLayout {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
}

-dontwarn org.json.**
-optimizationpasses 5
-allowaccessmodification
-repackageclasses 'x'
