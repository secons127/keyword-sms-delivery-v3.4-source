package com.example.keywordsmsforwarder;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.Signature;

import java.security.MessageDigest;
import java.util.Locale;

/** Runtime attribution and official-signature marker. */
final class BuildSeal {
    private static final int K = 0x5A;
    private static final int[] T = {23, 59, 62, 63, 122, 56, 35, 122, 22, 63, 63, 122, 9, 63, 50, 63, 63};
    private static final String OFFICIAL =
            "66D6B62EA8C3548F170340D7F5CA3583859327B8EF16F034A0E453996893E39E";

    private BuildSeal() { }

    static String label(Context context) {
        String credit = decode();
        return isOfficial(context) ? credit : "Unofficial build · " + credit;
    }

    static String decode() {
        StringBuilder value = new StringBuilder(T.length);
        for (int item : T) {
            value.append((char) (item ^ K));
        }
        return value.toString();
    }

    @SuppressWarnings("deprecation")
    private static boolean isOfficial(Context context) {
        try {
            Signature[] signatures = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES)
                    .signatures;
            if (signatures == null || signatures.length == 0) {
                return false;
            }
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(signatures[0].toByteArray());
            StringBuilder hex = new StringBuilder(bytes.length * 2);
            for (byte value : bytes) {
                hex.append(String.format(Locale.ROOT, "%02X", value));
            }
            return OFFICIAL.equals(hex.toString());
        } catch (Exception ignored) {
            return false;
        }
    }
}
