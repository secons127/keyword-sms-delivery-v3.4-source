package com.example.keywordsmsforwarder;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 최근 감지 기록을 기기 내부에만 최대 50개 저장합니다. 문자 본문은 저장하지 않습니다. */
public final class ForwardLogStore {
    private static final String PREFS = "settings";
    private static final String KEY_LOGS = "forward_logs_v1";
    private static final int MAX_LOGS = 50;

    private ForwardLogStore() {
    }

    public static void add(
            Context context,
            Rule rule,
            String sender,
            List<String> matchedKeywords,
            int destinationCount,
            String source
    ) {
        JSONArray current = readArray(context);
        JSONArray next = new JSONArray();
        JSONObject item = new JSONObject();
        try {
            item.put("time", System.currentTimeMillis());
            item.put("ruleName", rule.name == null ? "문자배달 설정" : rule.name);
            item.put("sender", maskAddress(sender));
            item.put("keywords", RuleStore.join(matchedKeywords, ", "));
            item.put("destinationCount", destinationCount);
            item.put("source", source == null ? "메시지" : source);
            next.put(item);
        } catch (JSONException ignored) {
        }

        for (int index = 0; index < current.length() && next.length() < MAX_LOGS; index++) {
            next.put(current.opt(index));
        }
        preferences(context).edit().putString(KEY_LOGS, next.toString()).apply();
    }

    public static List<Record> load(Context context) {
        List<Record> records = new ArrayList<>();
        JSONArray array = readArray(context);
        for (int index = 0; index < array.length(); index++) {
            JSONObject object = array.optJSONObject(index);
            if (object == null) {
                continue;
            }
            Record record = new Record();
            record.time = object.optLong("time", 0L);
            record.ruleName = object.optString("ruleName", "문자배달 설정");
            record.sender = object.optString("sender", "알 수 없음");
            record.keywords = object.optString("keywords", "");
            record.destinationCount = object.optInt("destinationCount", 0);
            record.source = object.optString("source", "메시지");
            records.add(record);
        }
        return records;
    }

    public static void clear(Context context) {
        preferences(context).edit().remove(KEY_LOGS).apply();
    }

    private static JSONArray readArray(Context context) {
        String raw = preferences(context).getString(KEY_LOGS, "");
        if (raw == null || raw.trim().isEmpty()) {
            return new JSONArray();
        }
        try {
            return new JSONArray(raw);
        } catch (JSONException ignored) {
            return new JSONArray();
        }
    }

    private static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String maskAddress(String value) {
        if (value == null || value.trim().isEmpty()) {
            return "알 수 없음";
        }
        String normalized = value.trim();
        if (normalized.length() <= 4) {
            return normalized;
        }
        int visible = Math.min(4, normalized.length());
        return "••••" + normalized.substring(normalized.length() - visible);
    }

    public static class Record {
        public long time;
        public String ruleName;
        public String sender;
        public String keywords;
        public int destinationCount;
        public String source;
    }
}
