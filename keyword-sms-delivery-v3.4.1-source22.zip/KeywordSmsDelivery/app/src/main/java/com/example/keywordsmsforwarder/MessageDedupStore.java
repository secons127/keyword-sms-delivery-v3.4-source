package com.example.keywordsmsforwarder;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Prevents one message from being forwarded twice through SMS and notification paths. */
public final class MessageDedupStore {
    private static final String PREFS = "settings";
    private static final String KEY_RECENT = "recent_message_claims_v3";
    private static final long WINDOW_MS = 45_000L;
    private static final int MAX_RECORDS = 24;

    private MessageDedupStore() { }

    /** Persist the claim before sending; only the first concurrent caller succeeds. */
    public static synchronized boolean claim(Context context, String sender, String body) {
        long now = System.currentTimeMillis();
        String full = hash(normalizedBody(body));
        String tail = hash(lastMeaningfulLine(body));
        String exact = hash(normalizedSender(sender) + "|" + normalizedBody(body));
        if (full.isEmpty()) {
            return false;
        }

        SharedPreferences preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray previous;
        try {
            previous = new JSONArray(preferences.getString(KEY_RECENT, "[]"));
        } catch (Exception ignored) {
            previous = new JSONArray();
        }

        JSONArray valid = new JSONArray();
        boolean duplicate = false;
        for (int index = 0; index < previous.length(); index++) {
            JSONObject item = previous.optJSONObject(index);
            if (item == null) {
                continue;
            }
            long time = item.optLong("time", 0L);
            if (now - time >= WINDOW_MS) {
                continue;
            }
            valid.put(item);
            String oldFull = item.optString("full");
            String oldTail = item.optString("tail");
            String oldExact = item.optString("exact");
            if (full.equals(oldFull)
                    || (!tail.isEmpty() && (tail.equals(oldTail) || tail.equals(oldFull)))
                    || (!oldTail.isEmpty() && full.equals(oldTail))
                    || exact.equals(oldExact)) {
                duplicate = true;
            }
        }

        if (!duplicate) {
            JSONObject current = new JSONObject();
            try {
                current.put("full", full);
                current.put("tail", tail);
                current.put("exact", exact);
                current.put("time", now);
                valid.put(current);
            } catch (Exception ignored) {
                return false;
            }
        }

        JSONArray trimmed = new JSONArray();
        int start = Math.max(0, valid.length() - MAX_RECORDS);
        for (int index = start; index < valid.length(); index++) {
            trimmed.put(valid.opt(index));
        }
        boolean saved = preferences.edit().putString(KEY_RECENT, trimmed.toString()).commit();
        return saved && !duplicate;
    }

    private static String normalizedSender(String sender) {
        return sender == null ? "" : sender
                .replaceAll("[^0-9a-zA-Z가-힣]", "")
                .toLowerCase(Locale.ROOT);
    }

    private static String normalizedBody(String body) {
        String normalized = body == null ? "" : body
                .replace('\u00a0', ' ')
                .replace("\u200B", "")
                .replace("\u200C", "")
                .replace("\u200D", "")
                .replaceAll("\\s+", " ")
                .trim()
                .toLowerCase(Locale.ROOT);
        return normalized.length() > 700 ? normalized.substring(0, 700) : normalized;
    }

    private static String lastMeaningfulLine(String body) {
        if (body == null) {
            return "";
        }
        String[] lines = body.replace('\u00a0', ' ').split("\\r?\\n");
        for (int index = lines.length - 1; index >= 0; index--) {
            String value = normalizedBody(lines[index]);
            if (!value.isEmpty()
                    && !"새 메시지".equals(value)
                    && !"new message".equals(value)
                    && !"메시지가 도착했습니다".equals(value)) {
                return value;
            }
        }
        return normalizedBody(body);
    }

    private static String hash(String value) {
        return value == null || value.isEmpty() ? "" : Integer.toHexString(value.hashCode());
    }
}
