package com.example.keywordsmsforwarder;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** SMS 또는 메시지 알림에서 감지한 텍스트를 규칙에 따라 전달합니다. */
public final class MessageForwarder {
    private static final String TAG = "MessageForwarder";

    private MessageForwarder() {
    }

    public static void process(Context context, String sender, String body, String source) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    && context.checkSelfPermission(Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            String cleanSender = sender == null || sender.trim().isEmpty() ? "알 수 없음" : sender.trim();
            String cleanBody = body == null ? "" : body.trim();
            if (cleanBody.isEmpty()) {
                return;
            }
            List<Rule> rules = RuleStore.load(context);
            if (rules.isEmpty()) {
                return;
            }

            List<Rule> matchingRules = new ArrayList<>();
            for (Rule rule : rules) {
                if (rule.matches(cleanBody)) {
                    matchingRules.add(rule);
                }
            }
            if (matchingRules.isEmpty() || !MessageDedupStore.claim(context, cleanSender, cleanBody)) {
                return;
            }

            SmsManager smsManager = SmsManager.getDefault();
            Set<String> sentDestinations = new HashSet<>();

            for (Rule rule : matchingRules) {

                // 연락처에 저장된 이름이 있으면 이름을, 없으면 원본 번호/발신명을 표시합니다.
                String senderLabel = resolveSenderLabel(context, cleanSender);
                String forwardedText = "[ " + senderLabel + " ]\n" + cleanBody;
                ArrayList<String> parts = smsManager.divideMessage(forwardedText);
                int sentForRule = 0;

                for (String destination : rule.destinations) {
                    String normalized = RuleStore.normalizePhone(destination);
                    if (normalized.isEmpty() || sentDestinations.contains(normalized)) {
                        continue;
                    }
                    sentDestinations.add(normalized);
                    sendNow(smsManager, normalized, forwardedText, parts);
                    sentForRule++;
                }

                if (sentForRule > 0) {
                    ForwardLogStore.add(
                            context,
                            rule,
                            cleanSender,
                            rule.matchedKeywords(cleanBody),
                            sentForRule,
                            safeSource(source)
                    );
                }
            }

        } catch (Exception exception) {
            Log.e(TAG, "메시지 자동 전달 오류", exception);
        }
    }


    private static String resolveSenderLabel(Context context, String sender) {
        if (sender == null || sender.trim().isEmpty()) {
            return "알 수 없음";
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && context.checkSelfPermission(Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            return sender;
        }

        Cursor cursor = null;
        try {
            Uri lookupUri = Uri.withAppendedPath(
                    ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                    Uri.encode(sender)
            );
            cursor = context.getContentResolver().query(
                    lookupUri,
                    new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME},
                    null,
                    null,
                    null
            );
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME);
                if (nameIndex >= 0) {
                    String displayName = cursor.getString(nameIndex);
                    if (displayName != null && !displayName.trim().isEmpty()) {
                        return displayName.trim();
                    }
                }
            }
        } catch (RuntimeException exception) {
            Log.w(TAG, "연락처 이름 확인 실패", exception);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return sender;
    }

    private static String safeRuleName(Rule rule) {
        return rule.name == null || rule.name.trim().isEmpty() ? "문자배달 설정" : rule.name;
    }

    private static String safeSource(String source) {
        return source == null || source.trim().isEmpty() ? "메시지" : source.trim();
    }

    private static void sendNow(
            SmsManager smsManager,
            String destination,
            String fullText,
            ArrayList<String> parts
    ) {
        if (parts.size() <= 1) {
            smsManager.sendTextMessage(destination, null, fullText, null, null);
        } else {
            smsManager.sendMultipartTextMessage(destination, null, parts, null, null);
        }
    }
}
