package com.example.keywordsmsforwarder;

import android.app.Notification;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.util.Log;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * 채팅플러스(RCS)와 MMS처럼 SMS_RECEIVED 방송으로 읽을 수 없는 메시지를
 * 사용자가 허용한 메시지 앱 알림에서 보조 감지합니다.
 */
public class MessageNotificationListener extends NotificationListenerService {
    private static final String TAG = "MessageNotification";
    private static final Set<String> KNOWN_MESSAGE_PACKAGES = new HashSet<>(Arrays.asList(
            "com.samsung.android.messaging",
            "com.google.android.apps.messaging",
            "com.android.messaging",
            "com.android.mms",
            "com.lge.message",
            "com.sonyericsson.conversations",
            "com.htc.sense.mms"
    ));

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null
                    || sbn.getNotification() == null
                    || !RuleStore.isNotificationCaptureEnabled(this)
                    || !isMessagePackage(sbn.getPackageName())) {
                return;
            }

            Notification notification = sbn.getNotification();
            if ((notification.flags & Notification.FLAG_GROUP_SUMMARY) != 0) {
                return;
            }

            Bundle extras = notification.extras;
            if (extras == null) {
                return;
            }

            String sender = firstNonEmpty(
                    extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE),
                    extras.getCharSequence(Notification.EXTRA_TITLE),
                    extras.getCharSequence(Notification.EXTRA_TITLE_BIG)
            );
            String body = extractBody(extras);

            if (body.isEmpty() || isGenericNotification(body)) {
                return;
            }

            MessageForwarder.process(this, sender, body, sourceName(sbn.getPackageName()));
        } catch (Exception exception) {
            Log.e(TAG, "메시지 알림 감지 오류", exception);
        }
    }

    private boolean isMessagePackage(String packageName) {
        if (packageName == null || packageName.equals(getPackageName())) {
            return false;
        }
        if (KNOWN_MESSAGE_PACKAGES.contains(packageName)) {
            return true;
        }
        String lower = packageName.toLowerCase(Locale.ROOT);
        return lower.contains("messaging") || lower.endsWith(".mms") || lower.contains("message");
    }

    private String extractBody(Bundle extras) {
        String messagingText = extractMessagingStyle(extras.getParcelableArray(Notification.EXTRA_MESSAGES));
        if (!messagingText.isEmpty()) {
            return messagingText;
        }

        String bigText = charSequence(extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
        if (!bigText.isEmpty()) {
            return bigText;
        }

        CharSequence[] lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (lines != null && lines.length > 0) {
            for (int index = lines.length - 1; index >= 0; index--) {
                String value = charSequence(lines[index]);
                if (!value.isEmpty()) {
                    return value;
                }
            }
        }

        return charSequence(extras.getCharSequence(Notification.EXTRA_TEXT));
    }

    private String extractMessagingStyle(Parcelable[] messageBundles) {
        if (messageBundles == null || messageBundles.length == 0) {
            return "";
        }
        Parcelable latest = messageBundles[messageBundles.length - 1];
        if (!(latest instanceof Bundle)) {
            return "";
        }
        Bundle bundle = (Bundle) latest;
        return charSequence(bundle.getCharSequence("text"));
    }

    private String firstNonEmpty(CharSequence... values) {
        for (CharSequence value : values) {
            String normalized = charSequence(value);
            if (!normalized.isEmpty()) {
                return normalized;
            }
        }
        return "알 수 없음";
    }

    private String charSequence(CharSequence value) {
        return value == null ? "" : value.toString().trim();
    }

    private boolean isGenericNotification(String body) {
        String normalized = body.trim().toLowerCase(Locale.ROOT);
        return TextUtils.isEmpty(normalized)
                || "새 메시지".equals(normalized)
                || "new message".equals(normalized)
                || "메시지가 도착했습니다".equals(normalized);
    }

    private String sourceName(String packageName) {
        if ("com.google.android.apps.messaging".equals(packageName)) {
            return "Google 메시지 알림";
        }
        if ("com.samsung.android.messaging".equals(packageName)) {
            return "삼성 메시지 알림";
        }
        return "메시지 앱 알림";
    }
}
