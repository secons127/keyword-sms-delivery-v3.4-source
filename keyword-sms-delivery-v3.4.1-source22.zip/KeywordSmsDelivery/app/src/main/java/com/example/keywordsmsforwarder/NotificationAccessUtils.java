package com.example.keywordsmsforwarder;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

/** 메시지 앱 알림 감지를 위한 알림 접근 권한 상태를 확인합니다. */
public final class NotificationAccessUtils {
    private NotificationAccessUtils() {
    }

    public static boolean isEnabled(Context context) {
        String enabled = Settings.Secure.getString(
                context.getContentResolver(),
                "enabled_notification_listeners"
        );
        if (enabled == null || enabled.trim().isEmpty()) {
            return false;
        }
        String[] components = enabled.split(":");
        for (String value : components) {
            ComponentName component = ComponentName.unflattenFromString(value);
            if (component != null && context.getPackageName().equals(component.getPackageName())) {
                return true;
            }
        }
        return false;
    }

    public static Intent settingsIntent() {
        return new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
    }
}
