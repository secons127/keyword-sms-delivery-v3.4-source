package com.example.keywordsmsforwarder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 한 개의 문자배달 설정을 표현합니다. */
public class Rule {
    public String id;
    public String name;
    public final List<String> destinations = new ArrayList<>();
    public final List<String> keywords = new ArrayList<>();
    public boolean enabled = true;
    public boolean matchAllKeywords = false;
    public long createdAt;
    public long updatedAt;

    public Rule() {
        id = String.valueOf(System.currentTimeMillis());
        createdAt = System.currentTimeMillis();
        updatedAt = createdAt;
    }

    public boolean matches(String body) {
        return enabled && matchesBody(body);
    }

    public boolean matchesBody(String body) {
        String normalizedBody = body == null ? "" : body.toLowerCase(Locale.ROOT);
        if (keywords.isEmpty()) {
            return false;
        }

        if (matchAllKeywords) {
            for (String keyword : keywords) {
                String normalized = normalizeKeyword(keyword);
                if (normalized.isEmpty() || !normalizedBody.contains(normalized)) {
                    return false;
                }
            }
            return true;
        }

        for (String keyword : keywords) {
            String normalized = normalizeKeyword(keyword);
            if (!normalized.isEmpty() && normalizedBody.contains(normalized)) {
                return true;
            }
        }
        return false;
    }


    public List<String> matchedKeywords(String body) {
        List<String> matched = new ArrayList<>();
        String normalizedBody = body == null ? "" : body.toLowerCase(Locale.ROOT);
        for (String keyword : keywords) {
            String normalized = normalizeKeyword(keyword);
            if (!normalized.isEmpty() && normalizedBody.contains(normalized)) {
                matched.add(keyword);
            }
        }
        return matched;
    }

    private String normalizeKeyword(String keyword) {
        return keyword == null ? "" : keyword.trim().toLowerCase(Locale.ROOT);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject object = new JSONObject();
        object.put("id", id);
        object.put("name", name);
        object.put("createdAt", createdAt);
        object.put("updatedAt", updatedAt);
        object.put("enabled", enabled);
        object.put("matchAllKeywords", matchAllKeywords);

        JSONArray destinationArray = new JSONArray();
        for (String destination : destinations) {
            destinationArray.put(destination);
        }
        object.put("destinations", destinationArray);

        JSONArray keywordArray = new JSONArray();
        for (String keyword : keywords) {
            keywordArray.put(keyword);
        }
        object.put("keywords", keywordArray);

        return object;
    }

    public static Rule fromJson(JSONObject object) throws JSONException {
        Rule rule = new Rule();
        rule.id = object.optString("id", rule.id);
        rule.name = object.optString("name", "문자배달 설정");
        rule.createdAt = object.optLong("createdAt", System.currentTimeMillis());
        rule.updatedAt = object.optLong("updatedAt", rule.createdAt);
        rule.enabled = object.optBoolean("enabled", true);
        rule.matchAllKeywords = object.optBoolean("matchAllKeywords", false);

        readArray(object.optJSONArray("destinations"), rule.destinations);
        readArray(object.optJSONArray("keywords"), rule.keywords);
        return rule;
    }

    private static void readArray(JSONArray array, List<String> target) {
        if (array == null) {
            return;
        }
        for (int index = 0; index < array.length(); index++) {
            String value = array.optString(index, "").trim();
            if (!value.isEmpty()) {
                target.add(value);
            }
        }
    }
}
