package com.example.keywordsmsforwarder;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** SharedPreferences 기반의 가벼운 설정 저장소입니다. */
public final class RuleStore {
    private static final String PREFS = "settings";
    private static final String KEY_RULES_V2 = "rules_v2";
    private static final String KEY_LEGACY_RULES = "rules";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_NOTIFICATION_CAPTURE = "notification_capture_enabled_v1";

    private RuleStore() {
    }

    public static List<Rule> load(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = preferences.getString(KEY_RULES_V2, "");
        if (raw != null && !raw.trim().isEmpty()) {
            return parseJson(raw);
        }

        List<Rule> rules = migrateLegacy(preferences);
        if (!rules.isEmpty()) {
            save(context, rules);
        }
        return rules;
    }

    public static void save(Context context, List<Rule> rules) {
        JSONArray array = new JSONArray();
        for (Rule rule : rules) {
            try {
                array.put(rule.toJson());
            } catch (JSONException ignored) {
                // 유효한 규칙만 저장합니다.
            }
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_RULES_V2, array.toString())
                .putString(KEY_LEGACY_RULES, buildLegacyRules(rules))
                .apply();
    }

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ENABLED, enabled)
                .apply();
    }


    public static boolean isNotificationCaptureEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_NOTIFICATION_CAPTURE, true);
    }

    public static void setNotificationCaptureEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_NOTIFICATION_CAPTURE, enabled)
                .apply();
    }

    public static String exportJson(Context context) {
        JSONArray array = new JSONArray();
        for (Rule rule : load(context)) {
            try {
                array.put(rule.toJson());
            } catch (JSONException ignored) {
            }
        }
        return array.toString();
    }

    public static List<Rule> parseJson(String raw) {
        List<Rule> rules = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) {
            return rules;
        }
        try {
            JSONArray array = new JSONArray(raw);
            for (int index = 0; index < array.length(); index++) {
                Rule rule = Rule.fromJson(array.getJSONObject(index));
                if (!rule.destinations.isEmpty() && !rule.keywords.isEmpty()) {
                    rules.add(rule);
                }
            }
        } catch (JSONException ignored) {
        }
        return rules;
    }

    public static List<Rule> parseLegacyRules(String raw) {
        List<Rule> rules = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) {
            return rules;
        }
        String[] lines = raw.split("\\n");
        int number = 1;
        for (String line : lines) {
            int separator = line.indexOf('|');
            if (separator <= 0) {
                continue;
            }
            String destination = Uri.decode(line.substring(0, separator)).trim();
            String keywordBlock = Uri.decode(line.substring(separator + 1));
            if (destination.isEmpty() || keywordBlock.trim().isEmpty()) {
                continue;
            }
            Rule rule = new Rule();
            rule.name = "가져온 설정 " + number++;
            rule.destinations.add(normalizePhone(destination));
            for (String keyword : keywordBlock.split("[,;\\n]+")) {
                String value = keyword.trim();
                if (!value.isEmpty()) {
                    rule.keywords.add(value);
                }
            }
            if (!rule.keywords.isEmpty()) {
                rules.add(rule);
            }
        }
        return rules;
    }

    private static List<Rule> migrateLegacy(SharedPreferences preferences) {
        List<Rule> rules = parseLegacyRules(preferences.getString(KEY_LEGACY_RULES, ""));
        if (!rules.isEmpty()) {
            return rules;
        }

        String destinations = preferences.getString("destination", "");
        String keywords = preferences.getString("keywords", "");
        if (destinations == null || keywords == null || keywords.trim().isEmpty()) {
            return rules;
        }
        Rule rule = new Rule();
        rule.name = "기존 문자배달 설정";
        for (String destination : destinations.split("[,;\\n]+")) {
            String normalized = normalizePhone(destination);
            if (!normalized.isEmpty()) {
                rule.destinations.add(normalized);
            }
        }
        for (String keyword : keywords.split("[,;\\n]+")) {
            String value = keyword.trim();
            if (!value.isEmpty()) {
                rule.keywords.add(value);
            }
        }
        if (!rule.destinations.isEmpty() && !rule.keywords.isEmpty()) {
            rules.add(rule);
        }
        return rules;
    }

    private static String buildLegacyRules(List<Rule> rules) {
        StringBuilder builder = new StringBuilder();
        for (Rule rule : rules) {
            if (!rule.enabled) {
                continue;
            }
            String keywordBlock = join(rule.keywords, ",");
            for (String destination : rule.destinations) {
                if (builder.length() > 0) {
                    builder.append('\n');
                }
                builder.append(Uri.encode(destination));
                builder.append('|');
                builder.append(Uri.encode(keywordBlock));
            }
        }
        return builder.toString();
    }

    public static String normalizePhone(String value) {
        if (value == null) {
            return "";
        }
        String normalized = value.trim().replaceAll("[-()\\s]", "");
        if (normalized.startsWith("+82") && normalized.length() > 3) {
            normalized = "0" + normalized.substring(3);
        } else if (normalized.startsWith("82") && normalized.length() >= 11) {
            normalized = "0" + normalized.substring(2);
        }
        return normalized;
    }

    public static String normalizeAddress(String value) {
        if (value == null) {
            return "";
        }
        String trimmed = value.trim();
        if (trimmed.matches("[+0-9()\\-\\s]+")) {
            return normalizePhone(trimmed);
        }
        return trimmed.replaceAll("\\s", "").toLowerCase(Locale.ROOT);
    }

    public static String join(List<String> values, String separator) {
        StringBuilder builder = new StringBuilder();
        for (String value : values) {
            if (builder.length() > 0) {
                builder.append(separator);
            }
            builder.append(value);
        }
        return builder.toString();
    }
}
