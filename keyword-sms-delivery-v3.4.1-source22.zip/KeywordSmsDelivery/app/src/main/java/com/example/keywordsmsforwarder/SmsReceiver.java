package com.example.keywordsmsforwarder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;

/** 일반 SMS를 직접 수신해 저장된 규칙으로 전달합니다. */
public class SmsReceiver extends BroadcastReceiver {
    private static final String TAG = "KeywordSmsForwarder";

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (intent == null
                    || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) {
                return;
            }

            SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
            if (messages == null || messages.length == 0) {
                return;
            }

            String sender = "알 수 없음";
            StringBuilder bodyBuilder = new StringBuilder();
            for (int index = 0; index < messages.length; index++) {
                SmsMessage message = messages[index];
                if (index == 0 && message.getOriginatingAddress() != null) {
                    sender = message.getOriginatingAddress();
                }
                if (message.getMessageBody() != null) {
                    bodyBuilder.append(message.getMessageBody());
                }
            }

            MessageForwarder.process(context, sender, bodyBuilder.toString(), "일반 SMS");
        } catch (Exception exception) {
            Log.e(TAG, "SMS 수신 처리 오류", exception);
        }
    }
}
