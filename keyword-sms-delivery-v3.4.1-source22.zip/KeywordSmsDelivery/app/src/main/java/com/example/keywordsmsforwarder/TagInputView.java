package com.example.keywordsmsforwarder;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** 쉼표·엔터 입력을 둥근 태그로 변환하는 입력 컴포넌트입니다. */
public class TagInputView extends LinearLayout {
    private static final int MODE_KEYWORD = 0;
    private static final int MODE_PHONE = 1;
    private static final int MODE_ADDRESS = 2;

    private final FlowLayout chipContainer;
    private final EditText editText;
    private final Set<String> tags = new LinkedHashSet<>();
    private int mode = MODE_KEYWORD;
    private boolean changingText;

    public TagInputView(Context context) {
        this(context, null);
    }

    public TagInputView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setOrientation(VERTICAL);

        chipContainer = new FlowLayout(context);
        LayoutParams chipParams = new LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT
        );
        chipContainer.setLayoutParams(chipParams);
        addView(chipContainer);

        editText = new EditText(context);
        editText.setTextSize(15);
        editText.setSingleLine(false);
        editText.setMinHeight(dp(48));
        editText.setPadding(dp(14), dp(10), dp(14), dp(10));
        editText.setBackground(createRoundedBackground(0xFFF9FAFD, 0xFFE5E9F2, 16, 1));
        editText.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        editText.setImeOptions(EditorInfo.IME_ACTION_DONE);
        LayoutParams inputParams = new LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT
        );
        inputParams.topMargin = dp(10);
        editText.setLayoutParams(inputParams);
        addView(editText);

        editText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable editable) {
                if (changingText) {
                    return;
                }
                String value = editable.toString();
                if (value.contains(",") || value.contains(";") || value.contains("\n")) {
                    changingText = true;
                    String[] parts = value.split("[,;\\n]+", -1);
                    for (int index = 0; index < parts.length - 1; index++) {
                        addTag(parts[index], true);
                    }
                    String remainder = parts.length == 0 ? "" : parts[parts.length - 1];
                    editText.setText(remainder);
                    editText.setSelection(remainder.length());
                    changingText = false;
                }
            }
        });

        editText.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                commitPending();
                return true;
            }
            return false;
        });
    }

    public void configure(boolean phoneMode, String hint) {
        mode = phoneMode ? MODE_PHONE : MODE_KEYWORD;
        applyConfiguration(hint);
    }

    public void configureAddress(String hint) {
        mode = MODE_ADDRESS;
        applyConfiguration(hint);
    }

    private void applyConfiguration(String hint) {
        editText.setHint(hint);
        editText.setInputType(mode == MODE_PHONE
                ? InputType.TYPE_CLASS_PHONE
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
    }

    public void commitPending() {
        String value = editText.getText().toString().trim();
        if (!value.isEmpty()) {
            addTag(value, true);
            editText.setText("");
        }
    }

    public boolean addTag(String rawValue, boolean showError) {
        String value = normalize(rawValue);
        if (value.isEmpty()) {
            return false;
        }
        if (mode == MODE_PHONE && !value.matches("\\+?[0-9]{8,15}")) {
            if (showError) {
                Toast.makeText(getContext(), "전화번호는 숫자 8~15자리로 입력해 주세요.", Toast.LENGTH_SHORT).show();
            }
            return false;
        }
        if (mode == MODE_ADDRESS && value.length() > 40) {
            if (showError) {
                Toast.makeText(getContext(), "발신 정보는 40자 이내로 입력해 주세요.", Toast.LENGTH_SHORT).show();
            }
            return false;
        }
        if (tags.contains(value)) {
            return true;
        }
        tags.add(value);
        renderChips();
        return true;
    }

    public void setTags(List<String> values) {
        tags.clear();
        if (values != null) {
            for (String value : values) {
                addTag(value, false);
            }
        }
        renderChips();
    }

    public List<String> getTags() {
        commitPending();
        return new ArrayList<>(tags);
    }

    public void clear() {
        tags.clear();
        editText.setText("");
        renderChips();
    }

    public void requestInputFocus() {
        editText.requestFocus();
    }

    private String normalize(String rawValue) {
        if (rawValue == null) {
            return "";
        }
        String value = rawValue.trim();
        if (mode == MODE_PHONE) {
            return RuleStore.normalizePhone(value);
        }
        if (mode == MODE_ADDRESS) {
            return RuleStore.normalizeAddress(value);
        }
        while (value.startsWith("#")) {
            value = value.substring(1).trim();
        }
        return value;
    }

    private void renderChips() {
        chipContainer.removeAllViews();
        chipContainer.setVisibility(tags.isEmpty() ? GONE : VISIBLE);
        for (String value : tags) {
            TextView chip = new TextView(getContext());
            String prefix = mode == MODE_KEYWORD ? "#" : "";
            chip.setText(prefix + value + "  ×");
            chip.setTextSize(13);
            chip.setTextColor(mode == MODE_ADDRESS ? 0xFF247D68 : 0xFF4255C7);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(12), dp(8), dp(11), dp(8));
            chip.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            chip.setBackground(createRoundedBackground(
                    mode == MODE_ADDRESS ? 0xFFE7F8F2 : 0xFFE9EDFF,
                    Color.TRANSPARENT,
                    99,
                    0
            ));
            chip.setOnClickListener(view -> {
                tags.remove(value);
                renderChips();
            });
            String type = mode == MODE_KEYWORD ? "키워드 " : mode == MODE_PHONE ? "전화번호 " : "발신 정보 ";
            chip.setContentDescription(type + value + " 삭제");
            chipContainer.addView(chip);
        }
    }

    private GradientDrawable createRoundedBackground(
            int fillColor,
            int strokeColor,
            int radiusDp,
            int strokeDp
    ) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) {
            drawable.setStroke(dp(strokeDp), strokeColor);
        }
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
