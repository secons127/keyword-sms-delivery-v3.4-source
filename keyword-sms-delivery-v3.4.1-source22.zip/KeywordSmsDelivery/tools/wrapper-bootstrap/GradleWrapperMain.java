package org.gradle.wrapper;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Minimal Gradle wrapper bootstrap used only because the recovered APK did not
 * contain its original Gradle wrapper files. It reads gradle-wrapper.properties,
 * downloads the configured Gradle distribution, extracts it, and launches Gradle.
 */
public final class GradleWrapperMain {

    private GradleWrapperMain() {
    }

    public static void main(String[] args) throws Exception {
        File jarFile = new File(
                GradleWrapperMain.class.getProtectionDomain()
                        .getCodeSource()
                        .getLocation()
                        .toURI()
        );
        File wrapperDirectory = jarFile.getParentFile();
        File propertiesFile = new File(wrapperDirectory, "gradle-wrapper.properties");

        Properties properties = new Properties();
        try (InputStream input = new FileInputStream(propertiesFile)) {
            properties.load(input);
        }

        String distributionUrl = properties.getProperty("distributionUrl");
        if (distributionUrl == null || distributionUrl.trim().isEmpty()) {
            throw new IllegalStateException("distributionUrl is missing from gradle-wrapper.properties");
        }

        distributionUrl = distributionUrl.replace("\\:", ":");
        int timeout = parseTimeout(properties.getProperty("networkTimeout"));

        File gradleUserHome = resolveGradleUserHome();
        File installRoot = new File(
                gradleUserHome,
                "wrapper/dists/custom-" + sha256(distributionUrl)
        );
        File marker = new File(installRoot, ".installed");

        if (!marker.isFile()) {
            installDistribution(distributionUrl, installRoot, timeout);
            if (!marker.createNewFile() && !marker.isFile()) {
                throw new IOException("Could not create Gradle installation marker: " + marker);
            }
        }

        File gradleHome = findGradleHome(installRoot);
        File executable = new File(
                gradleHome,
                isWindows() ? "bin/gradle.bat" : "bin/gradle"
        );
        if (!executable.isFile()) {
            throw new IOException("Gradle executable was not found: " + executable);
        }
        if (!isWindows()) {
            executable.setExecutable(true);
        }

        List<String> command = new ArrayList<>();
        command.add(executable.getAbsolutePath());
        for (String arg : args) {
            command.add(arg);
        }

        Process process = new ProcessBuilder(command)
                .directory(new File(System.getProperty("user.dir")))
                .inheritIO()
                .start();
        System.exit(process.waitFor());
    }

    private static int parseTimeout(String value) {
        if (value == null) {
            return 10000;
        }
        try {
            return Math.max(1000, Integer.parseInt(value));
        } catch (NumberFormatException ignored) {
            return 10000;
        }
    }

    private static File resolveGradleUserHome() {
        String configured = System.getenv("GRADLE_USER_HOME");
        if (configured != null && !configured.trim().isEmpty()) {
            return new File(configured);
        }
        return new File(System.getProperty("user.home"), ".gradle");
    }

    private static void installDistribution(String distributionUrl, File installRoot, int timeout)
            throws Exception {
        deleteRecursively(installRoot.toPath());
        if (!installRoot.mkdirs() && !installRoot.isDirectory()) {
            throw new IOException("Could not create Gradle install directory: " + installRoot);
        }

        File zipFile = new File(installRoot, "distribution.zip");
        File temporaryZip = new File(installRoot, "distribution.zip.part");

        download(distributionUrl, temporaryZip, timeout);
        Files.move(
                temporaryZip.toPath(),
                zipFile.toPath(),
                StandardCopyOption.REPLACE_EXISTING
        );
        unzip(zipFile, installRoot);
        if (!zipFile.delete()) {
            zipFile.deleteOnExit();
        }
    }

    private static void download(String sourceUrl, File destination, int timeout) throws Exception {
        URL current = URI.create(sourceUrl).toURL();
        for (int redirect = 0; redirect < 10; redirect++) {
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setConnectTimeout(timeout);
            connection.setReadTimeout(Math.max(timeout, 30000));
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("User-Agent", "KeywordSmsForwarder-GradleBootstrap/1.0");

            int responseCode = connection.getResponseCode();
            if (responseCode >= 300 && responseCode < 400) {
                String location = connection.getHeaderField("Location");
                connection.disconnect();
                if (location == null) {
                    throw new IOException("Gradle download redirected without a Location header");
                }
                current = new URL(current, location);
                continue;
            }

            if (responseCode < 200 || responseCode >= 300) {
                connection.disconnect();
                throw new IOException("Gradle download failed with HTTP " + responseCode);
            }

            try (InputStream input = new BufferedInputStream(connection.getInputStream());
                 BufferedOutputStream output = new BufferedOutputStream(
                         new FileOutputStream(destination)
                 )) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) != -1) {
                    output.write(buffer, 0, read);
                }
            } finally {
                connection.disconnect();
            }
            return;
        }
        throw new IOException("Too many redirects while downloading Gradle");
    }

    private static void unzip(File zipFile, File destinationDirectory) throws IOException {
        Path destinationRoot = destinationDirectory.toPath().toAbsolutePath().normalize();
        try (ZipInputStream input = new ZipInputStream(
                new BufferedInputStream(new FileInputStream(zipFile))
        )) {
            ZipEntry entry;
            while ((entry = input.getNextEntry()) != null) {
                Path outputPath = destinationRoot.resolve(entry.getName()).normalize();
                if (!outputPath.startsWith(destinationRoot)) {
                    throw new IOException("Unsafe path in Gradle distribution: " + entry.getName());
                }

                if (entry.isDirectory()) {
                    Files.createDirectories(outputPath);
                } else {
                    Files.createDirectories(outputPath.getParent());
                    try (BufferedOutputStream output = new BufferedOutputStream(
                            new FileOutputStream(outputPath.toFile())
                    )) {
                        byte[] buffer = new byte[8192];
                        int read;
                        while ((read = input.read(buffer)) != -1) {
                            output.write(buffer, 0, read);
                        }
                    }
                }
                input.closeEntry();
            }
        }
    }

    private static File findGradleHome(File installRoot) throws IOException {
        File[] directories = installRoot.listFiles(File::isDirectory);
        if (directories != null) {
            for (File directory : directories) {
                if (new File(directory, "bin/gradle").isFile()
                        || new File(directory, "bin/gradle.bat").isFile()) {
                    return directory;
                }
            }
        }
        throw new IOException("Extracted Gradle home was not found in " + installRoot);
    }

    private static String sha256(String value) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] bytes = digest.digest(value.getBytes("UTF-8"));
        StringBuilder result = new StringBuilder();
        for (int index = 0; index < 8; index++) {
            result.append(String.format("%02x", bytes[index]));
        }
        return result.toString();
    }

    private static void deleteRecursively(Path path) throws IOException {
        if (!Files.exists(path)) {
            return;
        }
        Files.walk(path)
                .sorted((left, right) -> right.compareTo(left))
                .forEach(item -> {
                    try {
                        Files.deleteIfExists(item);
                    } catch (IOException exception) {
                        throw new RuntimeException(exception);
                    }
                });
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "")
                .toLowerCase()
                .contains("win");
    }
}
