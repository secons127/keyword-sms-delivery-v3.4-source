package com.example.keywordsmsforwarder;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.Signature;

import java.security.MessageDigest;
import java.util.Locale;

final class BuildSeal {
    private static final int XOR_KEY = 0x5A;
    private static final int[] RAW_BYTES = {23, 59, 62, 63, 122, 56, 35, 122, 22, 63, 63, 122, 9, 63, 50, 63, 63};
    private static final String OFFICIAL_SIGNATURE =
            "66D6B62EA8C3548F170340D7F5CA3583859327B8EF16F034A0E453996893E39E";

    private BuildSeal() { }

    static String label(Context context) {
        String credit = decode();
        if (isOfficial(context)) {
            return credit;
        }
        return "Unofficial build · " + credit;
    }

    static String decode() {
        StringBuilder sb = new StringBuilder(RAW_BYTES.length);
        for (int b : RAW_BYTES) {
            sb.append((char) (b ^ XOR_KEY));
        }
        return sb.toString();
    }

    @SuppressWarnings("deprecation")
    private static boolean isOfficial(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            Signature[] signatures = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES).signatures;
            if (signatures == null || signatures.length == 0) {
                return false;
            }

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(signatures[0].toByteArray());
            
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                sb.append(String.format(Locale.ROOT, "%02X", b));
            }
            return OFFICIAL_SIGNATURE.equals(sb.toString());
        } catch (Exception e) {
            return false;
        }
    }
}