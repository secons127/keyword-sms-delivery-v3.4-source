package com.example.keywordsmsforwarder;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

public class FlowLayout extends ViewGroup {
    private int hSpacing;
    private int vSpacing;

    public FlowLayout(Context context) {
        this(context, null);
    }

    public FlowLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        float density = getResources().getDisplayMetrics().density;
        hSpacing = (int) (8 * density);
        vSpacing = (int) (8 * density);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        
        int available = Integer.MAX_VALUE;
        if (widthMode != MeasureSpec.UNSPECIFIED) {
            available = width - getPaddingLeft() - getPaddingRight();
        }

        int lineWidth = 0;
        int lineHeight = 0;
        int totalHeight = getPaddingTop() + getPaddingBottom();
        int maxWidth = 0;

        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == GONE) {
                continue;
            }
            
            measureChild(child, widthMeasureSpec, heightMeasureSpec);
            int childWidth = child.getMeasuredWidth();
            int childHeight = child.getMeasuredHeight();

            if (lineWidth > 0 && lineWidth + hSpacing + childWidth > available) {
                totalHeight += lineHeight + vSpacing;
                maxWidth = Math.max(maxWidth, lineWidth);
                lineWidth = childWidth;
                lineHeight = childHeight;
            } else {
                if (lineWidth > 0) {
                    lineWidth += hSpacing;
                }
                lineWidth += childWidth;
                lineHeight = Math.max(lineHeight, childHeight);
            }
        }
        totalHeight += lineHeight;
        maxWidth = Math.max(maxWidth, lineWidth);

        int measuredWidth = maxWidth + getPaddingLeft() + getPaddingRight();
        if (widthMode == MeasureSpec.EXACTLY) {
            measuredWidth = width;
        }

        setMeasuredDimension(
                resolveSize(measuredWidth, widthMeasureSpec),
                resolveSize(totalHeight, heightMeasureSpec)
        );
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        int available = right - left - getPaddingLeft() - getPaddingRight();
        int x = getPaddingLeft();
        int y = getPaddingTop();
        int lineHeight = 0;

        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == GONE) {
                continue;
            }

            int childWidth = child.getMeasuredWidth();
            int childHeight = child.getMeasuredHeight();
            
            if (x > getPaddingLeft() && x + childWidth > available + getPaddingLeft()) {
                x = getPaddingLeft();
                y += lineHeight + vSpacing;
                lineHeight = 0;
            }
            
            child.layout(x, y, x + childWidth, y + childHeight);
            x += childWidth + hSpacing;
            lineHeight = Math.max(lineHeight, childHeight);
        }
    }
}