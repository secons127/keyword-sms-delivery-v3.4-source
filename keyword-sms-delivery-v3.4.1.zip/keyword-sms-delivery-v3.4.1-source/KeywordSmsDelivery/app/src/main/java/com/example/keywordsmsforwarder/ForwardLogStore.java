package com.example.keywordsmsforwarder;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class ForwardLogStore {
    private static final String PREFS_NAME = "settings";
    private static final String KEY_LOGS = "forward_logs_v1";
    private static final int MAX_LOGS = 50;

    private ForwardLogStore() {
    }

    public static void add(
            Context context,
            Rule rule,
            String sender,
            List<String> matchedKeywords,
            int destinationCount,
            String source
    ) {
        JSONArray current = readArray(context);
        JSONArray next = new JSONArray();
        JSONObject item = new JSONObject();
        
        try {
            item.put("time", System.currentTimeMillis());
            
            String ruleName = "문자배달 설정";
            if (rule != null && rule.name != null) {
                ruleName = rule.name;
            }
            item.put("ruleName", ruleName);
            
            item.put("sender", maskAddress(sender));
            item.put("keywords", RuleStore.join(matchedKeywords, ", "));
            item.put("destinationCount", destinationCount);
            
            String src = "메시지";
            if (source != null) {
                src = source;
            }
            item.put("source", src);
            
            next.put(item);
        } catch (JSONException e) {
            // log put error
        }

        int len = current.length();
        for (int i = 0; i < len && next.length() < MAX_LOGS; i++) {
            next.put(current.opt(i));
        }
        
        getPrefs(context).edit().putString(KEY_LOGS, next.toString()).apply();
    }

    public static List<Record> load(Context context) {
        List<Record> list = new ArrayList<>();
        JSONArray arr = readArray(context);
        
        int len = arr.length();
        for (int i = 0; i < len; i++) {
            JSONObject obj = arr.optJSONObject(i);
            if (obj == null) {
                continue;
            }
            
            Record rec = new Record();
            rec.time = obj.optLong("time", 0L);
            rec.ruleName = obj.optString("ruleName", "문자배달 설정");
            rec.sender = obj.optString("sender", "알 수 없음");
            rec.keywords = obj.optString("keywords", "");
            rec.destinationCount = obj.optInt("destinationCount", 0);
            rec.source = obj.optString("source", "메시지");
            list.add(rec);
        }
        return list;
    }

    public static void clear(Context context) {
        getPrefs(context).edit().remove(KEY_LOGS).apply();
    }

    private static JSONArray readArray(Context context) {
        String raw = getPrefs(context).getString(KEY_LOGS, "");
        if (raw == null || raw.trim().isEmpty()) {
            return new JSONArray();
        }
        try {
            return new JSONArray(raw);
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    private static String maskAddress(String value) {
        if (value == null || value.trim().isEmpty()) {
            return "알 수 없음";
        }
        String str = value.trim();
        if (str.length() <= 4) {
            return str;
        }
        int visible = Math.min(4, str.length());
        return "••••" + str.substring(str.length() - visible);
    }

    public static class Record {
        public long time;
        public String ruleName;
        public String sender;
        public String keywords;
        public int destinationCount;
        public String source;
    }
}