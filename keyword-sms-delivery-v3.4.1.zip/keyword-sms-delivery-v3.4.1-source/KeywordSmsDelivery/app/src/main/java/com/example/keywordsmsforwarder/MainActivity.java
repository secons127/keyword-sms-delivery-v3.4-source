package com.example.keywordsmsforwarder;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQUEST_SMS_PERMISSIONS = 100;
    private static final int REQUEST_PICK_CONTACT = 1002;
    private static final int REQUEST_CONTACTS_PERMISSION = 103;

    private FrameLayout contentContainer;
    private LinearLayout navCreate;
    private LinearLayout navManage;
    private LinearLayout navSettings;
    private TextView textHeaderStatus;

    private int currentTab = 0;
    private String editingRuleId;
    private TagInputView contactTarget;

    private EditText editRuleName;
    private TagInputView phoneTags;
    private TagInputView keywordTags;
    private RadioButton radioAny;
    private RadioButton radioAll;
    private Switch ruleEnabledSwitch;
    private TextView settingsSmsStatus;
    private TextView settingsContactsStatus;
    private TextView settingsNotificationStatus;
    private TextView settingsSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(0xFFF5F7FC);
            getWindow().setNavigationBarColor(0xFFFFFFFF);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        contentContainer = findViewById(R.id.contentContainer);
        navCreate = findViewById(R.id.navCreate);
        navManage = findViewById(R.id.navManage);
        navSettings = findViewById(R.id.navSettings);
        textHeaderStatus = findViewById(R.id.textHeaderStatus);

        navCreate.setOnClickListener(view -> showCreateTab(null));
        navManage.setOnClickListener(view -> showManageTab());
        navSettings.setOnClickListener(view -> showSettingsTab());

        boolean imported = handleImportIntent(getIntent());
        if (!imported) {
            showCreateTab(null);
        }
        updateHeaderStatus();
    }

    private void showCreateTab(String ruleId) {
        currentTab = 0;
        editingRuleId = ruleId;
        clearSettingsStatusReferences();
        contentContainer.removeAllViews();
        LayoutInflater.from(this).inflate(R.layout.tab_create, contentContainer, true);

        editRuleName = findViewById(R.id.editRuleName);
        phoneTags = findViewById(R.id.phoneTagInput);
        keywordTags = findViewById(R.id.keywordTagInput);
        radioAny = findViewById(R.id.radioAny);
        radioAll = findViewById(R.id.radioAll);
        ruleEnabledSwitch = findViewById(R.id.switchRuleEnabled);

        phoneTags.configure(true, "01012345678 입력 후 쉼표(,) 또는 엔터");
        keywordTags.configure(false, "배송완료, 긴급 입력 후 쉼표(,) 또는 엔터");

        findViewById(R.id.buttonPickContact).setOnClickListener(view -> pickContact(phoneTags));
        findViewById(R.id.buttonSaveRule).setOnClickListener(view -> saveCurrentRule());
        findViewById(R.id.buttonClearForm).setOnClickListener(view -> clearForm());

        TextView pageTitle = findViewById(R.id.textCreateTitle);
        Button saveButton = findViewById(R.id.buttonSaveRule);
        if (ruleId != null) {
            Rule rule = findRule(ruleId);
            if (rule != null) {
                editRuleName.setText(rule.name);
                phoneTags.setTags(rule.destinations);
                keywordTags.setTags(rule.keywords);
                radioAll.setChecked(rule.matchAllKeywords);
                radioAny.setChecked(!rule.matchAllKeywords);
                ruleEnabledSwitch.setChecked(rule.enabled);
                pageTitle.setText("문자배달 설정 수정");
                saveButton.setText("수정 내용 저장");
            }
        } else {
            ruleEnabledSwitch.setChecked(true);
        }

        updateBottomNavigation();
    }

    private void showManageTab() {
        currentTab = 1;
        editingRuleId = null;
        clearSettingsStatusReferences();
        contentContainer.removeAllViews();
        LayoutInflater.from(this).inflate(R.layout.tab_manage, contentContainer, true);

        LinearLayout rulesContainer = findViewById(R.id.containerManageRules);
        TextView empty = findViewById(R.id.textManageEmpty);
        TextView summary = findViewById(R.id.textManageSummary);
        TextView bulkStatus = findViewById(R.id.textBulkStatus);
        Switch bulkSwitch = findViewById(R.id.switchGlobalForwarding);
        List<Rule> rules = RuleStore.load(this);

        updateManageSummary(summary, rules);
        updateBulkStatus(bulkStatus, rules);
        bulkSwitch.setEnabled(!rules.isEmpty());
        bulkSwitch.setChecked(RuleStore.isEnabled(this));
        bulkSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            RuleStore.setEnabled(this, isChecked);
            long now = System.currentTimeMillis();
            List<Rule> currentRules = RuleStore.load(this);
            for (Rule rule : currentRules) {
                rule.enabled = isChecked;
                rule.updatedAt = now;
            }
            RuleStore.save(this, currentRules);
            updateHeaderStatus();
            Toast.makeText(
                    this,
                    isChecked ? "모든 설정을 켰어요." : "모든 설정을 껐어요.",
                    Toast.LENGTH_SHORT
            ).show();
            showManageTab();
        });

        findViewById(R.id.buttonCopySettings).setOnClickListener(view -> copySettingsLink());
        findViewById(R.id.buttonImportSettings).setOnClickListener(view -> showImportDialog());
        findViewById(R.id.buttonClearLogs).setOnClickListener(view -> confirmClearLogs());

        if (rules.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
        } else {
            empty.setVisibility(View.GONE);
            for (Rule rule : rules) {
                addManageRuleCard(rulesContainer, rule, rules, summary);
            }
        }

        renderLogs();
        updateBottomNavigation();
    }

    private void showSettingsTab() {
        currentTab = 2;
        editingRuleId = null;
        contentContainer.removeAllViews();
        LayoutInflater.from(this).inflate(R.layout.tab_settings, contentContainer, true);

        settingsSummary = findViewById(R.id.textSettingsSummary);
        settingsSmsStatus = findViewById(R.id.textSettingsSmsStatus);
        settingsContactsStatus = findViewById(R.id.textSettingsContactsStatus);
        settingsNotificationStatus = findViewById(R.id.textSettingsNotificationStatus);
        TextView buildCredit = findViewById(R.id.textBuildCredit);
        buildCredit.setText(BuildSeal.label(this));
        buildCredit.setContentDescription(BuildSeal.decode());
        Switch notificationSwitch = findViewById(R.id.switchSettingsNotificationCapture);

        findViewById(R.id.buttonSettingsSms).setOnClickListener(view -> requestSmsPermissions());
        findViewById(R.id.buttonSettingsContacts).setOnClickListener(view -> requestContactsPermission());
        findViewById(R.id.buttonSettingsNotification).setOnClickListener(view -> openNotificationAccess());

        notificationSwitch.setChecked(RuleStore.isNotificationCaptureEnabled(this));
        notificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            RuleStore.setNotificationCaptureEnabled(this, isChecked);
            updateSettingsStatuses();
            if (isChecked && !NotificationAccessUtils.isEnabled(this)) {
                openNotificationAccess();
            }
        });

        updateSettingsStatuses();
        updateBottomNavigation();
    }

    private void clearSettingsStatusReferences() {
        settingsSmsStatus = null;
        settingsContactsStatus = null;
        settingsNotificationStatus = null;
        settingsSummary = null;
    }

    private void addManageRuleCard(
            LinearLayout parent,
            Rule rule,
            List<Rule> allRules,
            TextView summary
    ) {
        View card = LayoutInflater.from(this).inflate(R.layout.item_rule_manage, parent, false);
        bindRuleCard(card, rule);

        Switch enabledSwitch = card.findViewById(R.id.switchRuleCardEnabled);
        Button editButton = card.findViewById(R.id.buttonEditRule);
        Button deleteButton = card.findViewById(R.id.buttonDeleteRule);

        enabledSwitch.setChecked(rule.enabled);
        card.setAlpha(rule.enabled ? 1f : 0.62f);
        enabledSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            rule.enabled = isChecked;
            rule.updatedAt = System.currentTimeMillis();
            RuleStore.save(this, allRules);
            RuleStore.setEnabled(this, false);
            card.setAlpha(isChecked ? 1f : 0.62f);
            updateManageSummary(summary, allRules);
            updateHeaderStatus();
            Toast.makeText(
                    this,
                    isChecked ? "설정을 활성화했어요." : "설정을 일시 중지했어요.",
                    Toast.LENGTH_SHORT
            ).show();
            showManageTab();
        });
        editButton.setOnClickListener(view -> showCreateTab(rule.id));
        deleteButton.setOnClickListener(view -> confirmDelete(rule));
        parent.addView(card);
    }

    private void bindRuleCard(View card, Rule rule) {
        TextView name = card.findViewById(R.id.textRuleName);
        TextView destinations = card.findViewById(R.id.textRuleDestinations);
        TextView matchMode = card.findViewById(R.id.textRuleMatchMode);
        TextView date = card.findViewById(R.id.textRuleDate);
        FlowLayout keywordContainer = card.findViewById(R.id.keywordChipContainer);

        name.setText(safeRuleName(rule));
        destinations.setText("전달 대상  " + RuleStore.join(rule.destinations, " · "));
        matchMode.setText(rule.matchAllKeywords
                ? "조건  모든 키워드 일치"
                : "조건  키워드 하나라도 일치");
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm 수정", Locale.KOREA);
        date.setText(sdf.format(new Date(rule.updatedAt)));

        keywordContainer.removeAllViews();
        for (String kw : rule.keywords) {
            keywordContainer.addView(createKeywordChip(kw));
        }
    }

    private TextView createKeywordChip(String keyword) {
        TextView chip = new TextView(this);
        chip.setText("#" + keyword);
        chip.setTextSize(12);
        chip.setTextColor(0xFF4255C7);
        chip.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        chip.setPadding(dp(11), dp(6), dp(11), dp(6));
        GradientDrawable background = new GradientDrawable();
        background.setColor(0xFFE9EDFF);
        background.setCornerRadius(dp(99));
        chip.setBackground(background);
        return chip;
    }

    private void saveCurrentRule() {
        Rule formRule = collectFormRule(true);
        if (formRule == null) {
            return;
        }

        List<Rule> rules = RuleStore.load(this);
        Rule target = editingRuleId == null ? null : findRuleInList(rules, editingRuleId);
        boolean isNew = target == null;
        if (target == null) {
            target = new Rule();
        }

        target.name = formRule.name;
        target.destinations.clear();
        target.destinations.addAll(formRule.destinations);
        target.keywords.clear();
        target.keywords.addAll(formRule.keywords);
        target.matchAllKeywords = formRule.matchAllKeywords;
        target.enabled = formRule.enabled;
        target.updatedAt = System.currentTimeMillis();

        if (isNew) {
            rules.add(target);
        }
        RuleStore.save(this, rules);
        updateHeaderStatus();

        Toast.makeText(
                this,
                isNew ? "문자배달 설정을 저장했어요." : "수정 내용을 저장했어요.",
                Toast.LENGTH_SHORT
        ).show();

        showCreateTab(null);
    }

    private Rule collectFormRule(boolean requireDestinations) {
        phoneTags.commitPending();
        keywordTags.commitPending();
        List<String> destinations = phoneTags.getTags();
        List<String> keywords = keywordTags.getTags();

        if (requireDestinations && destinations.isEmpty()) {
            Toast.makeText(this, "문자를 전달받을 전화번호를 한 개 이상 추가해 주세요.", Toast.LENGTH_LONG).show();
            phoneTags.requestInputFocus();
            return null;
        }
        if (keywords.isEmpty()) {
            Toast.makeText(this, "찾을 키워드를 한 개 이상 추가해 주세요.", Toast.LENGTH_LONG).show();
            keywordTags.requestInputFocus();
            return null;
        }

        Rule rule = new Rule();
        String name = editRuleName.getText().toString().trim();
        if (name.isEmpty()) {
            name = "#" + keywords.get(0) + " 문자배달";
        }
        rule.name = name;
        rule.destinations.addAll(destinations);
        rule.keywords.addAll(keywords);
        rule.matchAllKeywords = radioAll.isChecked();
        rule.enabled = ruleEnabledSwitch.isChecked();
        return rule;
    }

    private void clearForm() {
        editingRuleId = null;
        editRuleName.setText("");
        phoneTags.clear();
        keywordTags.clear();
        radioAny.setChecked(true);
        ruleEnabledSwitch.setChecked(true);
        TextView title = findViewById(R.id.textCreateTitle);
        Button saveButton = findViewById(R.id.buttonSaveRule);
        title.setText("새 문자배달 설정");
        saveButton.setText("설정 저장");
    }

    private Rule findRule(String id) {
        return findRuleInList(RuleStore.load(this), id);
    }

    private Rule findRuleInList(List<Rule> rules, String id) {
        if (id == null) {
            return null;
        }
        for (Rule rule : rules) {
            if (id.equals(rule.id)) {
                return rule;
            }
        }
        return null;
    }

    private void confirmDelete(Rule target) {
        new AlertDialog.Builder(this)
                .setTitle("설정을 삭제할까요?")
                .setMessage("‘" + safeRuleName(target) + "’ 설정은 삭제 후 복구할 수 없어요.")
                .setNegativeButton("취소", null)
                .setPositiveButton("삭제", (dialog, which) -> {
                    List<Rule> rules = RuleStore.load(this);
                    List<Rule> remaining = new ArrayList<>();
                    for (Rule rule : rules) {
                        if (!target.id.equals(rule.id)) {
                            remaining.add(rule);
                        }
                    }
                    RuleStore.save(this, remaining);
                    updateHeaderStatus();
                    Toast.makeText(this, "설정을 삭제했어요.", Toast.LENGTH_SHORT).show();
                    showManageTab();
                })
                .show();
    }

    private void renderLogs() {
        LinearLayout container = findViewById(R.id.containerLogs);
        TextView empty = findViewById(R.id.textLogsEmpty);
        List<ForwardLogStore.Record> records = ForwardLogStore.load(this);
        if (records.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            return;
        }
        empty.setVisibility(View.GONE);
        for (ForwardLogStore.Record rec : records) {
            addLogCard(container, rec);
        }
    }

    private void addLogCard(LinearLayout parent, ForwardLogStore.Record record) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.bottomMargin = dp(8);
        card.setLayoutParams(cardParams);

        TextView title = new TextView(this);
        title.setText(record.ruleName);
        title.setTextColor(0xFF252832);
        title.setTextSize(14);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        card.addView(title);

        SimpleDateFormat sdf = new SimpleDateFormat("MM.dd HH:mm", Locale.KOREA);
        String timeStr = sdf.format(new Date(record.time));
        String srcStr = record.source == null ? "메시지" : record.source;
        String kwStr = record.keywords.isEmpty() ? "" : "\n감지: #" + record.keywords.replace(", ", "  #");
        
        TextView detail = new TextView(this);
        detail.setText(timeStr
                + " · " + srcStr
                + " · 발신 " + record.sender
                + " · " + record.destinationCount + "명 전달 요청"
                + kwStr);
        detail.setTextColor(0xFF6B6E78);
        detail.setTextSize(12);
        detail.setLineSpacing(0f, 1.15f);
        
        LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        detailParams.topMargin = dp(5);
        card.addView(detail, detailParams);
        parent.addView(card);
    }

    private void confirmClearLogs() {
        if (ForwardLogStore.load(this).isEmpty()) {
            Toast.makeText(this, "비울 기록이 없어요.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("최근 기록을 비울까요?")
                .setMessage("기기에 저장된 감지 기록만 삭제되며 문자배달 설정은 유지돼요.")
                .setNegativeButton("취소", null)
                .setPositiveButton("비우기", (dialog, which) -> {
                    ForwardLogStore.clear(this);
                    Toast.makeText(this, "최근 기록을 비웠어요.", Toast.LENGTH_SHORT).show();
                    showManageTab();
                })
                .show();
    }

    private void copySettingsLink() {
        List<Rule> rules = RuleStore.load(this);
        if (rules.isEmpty()) {
            Toast.makeText(this, "먼저 문자배달 설정을 저장해 주세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        String link = "smsforwarder://import?v=3&data=" + Uri.encode(RuleStore.exportJson(this));
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null) {
            return;
        }
        clipboard.setPrimaryClip(ClipData.newPlainText("문자배달 설정 링크", link));
        Toast.makeText(this, "설정 링크를 복사했어요.", Toast.LENGTH_LONG).show();
    }

    private void showImportDialog() {
        EditText input = new EditText(this);
        input.setHint("전달받은 smsforwarder:// 링크 또는 설정 JSON을 붙여 넣으세요.");
        input.setMinLines(5);
        input.setGravity(android.view.Gravity.TOP);
        input.setTextSize(13);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));

        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(dp(22), dp(8), dp(22), 0);
        wrapper.addView(input, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        new AlertDialog.Builder(this)
                .setTitle("설정 가져오기")
                .setMessage("중복된 설정은 자동으로 제외해요.")
                .setView(wrapper)
                .setNegativeButton("취소", null)
                .setPositiveButton("가져오기", (dialog, which) -> {
                    List<Rule> imported = parseImportInput(input.getText().toString());
                    importRules(imported);
                })
                .show();
    }

    private List<Rule> parseImportInput(String rawInput) {
        String raw = rawInput == null ? "" : rawInput.trim();
        if (raw.isEmpty()) {
            return new ArrayList<>();
        }
        try {
            Uri uri = Uri.parse(raw);
            if ("smsforwarder".equals(uri.getScheme()) && "import".equals(uri.getHost())) {
                List<Rule> rules = RuleStore.parseJson(uri.getQueryParameter("data"));
                if (rules.isEmpty()) {
                    rules = RuleStore.parseLegacyRules(uri.getQueryParameter("rules"));
                }
                return rules;
            }
        } catch (RuntimeException e) {
        }
        return RuleStore.parseJson(raw);
    }

    private boolean importRules(List<Rule> imported) {
        if (imported == null || imported.isEmpty()) {
            Toast.makeText(this, "가져올 수 있는 설정을 찾지 못했어요.", Toast.LENGTH_LONG).show();
            return false;
        }

        List<Rule> current = RuleStore.load(this);
        Set<String> signatures = new HashSet<>();
        for (Rule rule : current) {
            signatures.add(ruleSignature(rule));
        }

        int added = 0;
        long now = System.currentTimeMillis();
        for (Rule rule : imported) {
            String signature = ruleSignature(rule);
            if (signatures.contains(signature)) {
                continue;
            }
            rule.id = String.valueOf(System.nanoTime() + added);
            rule.createdAt = now;
            rule.updatedAt = now;
            current.add(rule);
            signatures.add(signature);
            added++;
        }

        if (added == 0) {
            Toast.makeText(this, "모두 이미 저장된 설정이에요.", Toast.LENGTH_LONG).show();
            return false;
        }
        RuleStore.save(this, current);
        updateHeaderStatus();
        Toast.makeText(this, "문자배달 설정 " + added + "개를 가져왔어요.", Toast.LENGTH_LONG).show();
        showManageTab();
        return true;
    }

    private String ruleSignature(Rule rule) {
        return safeRuleName(rule).trim().toLowerCase(Locale.ROOT)
                + "|" + RuleStore.join(rule.destinations, ",")
                + "|" + RuleStore.join(rule.keywords, ",").toLowerCase(Locale.ROOT)
                + "|" + rule.matchAllKeywords;
    }

    private boolean handleImportIntent(Intent intent) {
        if (intent == null || intent.getData() == null) {
            return false;
        }
        Uri uri = intent.getData();
        if (!"smsforwarder".equals(uri.getScheme()) || !"import".equals(uri.getHost())) {
            return false;
        }

        List<Rule> imported = RuleStore.parseJson(uri.getQueryParameter("data"));
        if (imported.isEmpty()) {
            imported = RuleStore.parseLegacyRules(uri.getQueryParameter("rules"));
        }
        return importRules(imported);
    }

    private void updateManageSummary(TextView summary, List<Rule> rules) {
        int active = 0;
        for (Rule rule : rules) {
            if (rule.enabled) {
                active++;
            }
        }
        summary.setText("저장 " + rules.size() + "개 · 활성 " + active + "개");
    }

    private void updateHeaderStatus() {
        if (textHeaderStatus == null) {
            return;
        }
        List<Rule> rules = RuleStore.load(this);
        int active = countActiveRules(rules);
        if (rules.isEmpty()) {
            textHeaderStatus.setText("설정 없음");
            textHeaderStatus.setTextColor(0xFF8C93A5);
        } else if (active == 0) {
            textHeaderStatus.setText("자동 전달 OFF · 설정 " + rules.size() + "개");
            textHeaderStatus.setTextColor(0xFF8C93A5);
        } else if (active == rules.size()) {
            textHeaderStatus.setText("자동 전달 ON · 활성 " + active + "개");
            textHeaderStatus.setTextColor(0xFF258566);
        } else {
            textHeaderStatus.setText("일부 설정 ON · " + active + "/" + rules.size());
            textHeaderStatus.setTextColor(0xFF5368F5);
        }
    }

    private void updateBottomNavigation() {
        styleNav(navCreate, R.id.navCreateIcon, R.id.navCreateLabel, currentTab == 0);
        styleNav(navManage, R.id.navManageIcon, R.id.navManageLabel, currentTab == 1);
        styleNav(navSettings, R.id.navSettingsIcon, R.id.navSettingsLabel, currentTab == 2);
    }

    private void styleNav(LinearLayout nav, int iconId, int labelId, boolean selected) {
        int color = selected ? 0xFF5368F5 : 0xFF929AAB;
        TextView icon = nav.findViewById(iconId);
        TextView label = nav.findViewById(labelId);
        icon.setTextColor(color);
        label.setTextColor(color);
        label.setTypeface(Typeface.create(
                "sans-serif-medium",
                selected ? Typeface.BOLD : Typeface.NORMAL
        ));
        GradientDrawable background = new GradientDrawable();
        background.setColor(selected ? 0xFFE9EDFF : 0x00FFFFFF);
        background.setCornerRadius(dp(18));
        nav.setBackground(background);
    }

    private void updatePermissionStatus(TextView target) {
        if (target == null) {
            return;
        }
        boolean ready = hasSmsPermissions();
        target.setText(ready
                ? "준비 완료 · 일반 SMS 수신과 전달 가능"
                : "문자 수신·발송 권한이 필요해요");
        target.setTextColor(ready ? 0xFF258566 : 0xFFC0616F);
    }

    private void openNotificationAccess() {
        try {
            startActivity(NotificationAccessUtils.settingsIntent());
            Toast.makeText(this, "목록에서 문자배달 알림 접근을 허용해 주세요.", Toast.LENGTH_LONG).show();
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "알림 접근 설정을 열 수 없어요.", Toast.LENGTH_LONG).show();
        }
    }

    private void updateNotificationStatus(TextView target) {
        if (target == null) {
            return;
        }
        boolean featureEnabled = RuleStore.isNotificationCaptureEnabled(this);
        boolean accessEnabled = NotificationAccessUtils.isEnabled(this);
        if (!featureEnabled) {
            target.setText("알림 감지 기능이 꺼져 있어요");
            target.setTextColor(0xFF8C93A5);
        } else if (accessEnabled) {
            target.setText("준비 완료 · 메시지 앱 알림 감지 가능");
            target.setTextColor(0xFF258566);
        } else {
            target.setText("알림 접근 허용이 필요해요");
            target.setTextColor(0xFFC0616F);
        }
    }

    private void requestSmsPermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || hasSmsPermissions()) {
            Toast.makeText(this, "SMS 권한이 이미 허용되어 있어요.", Toast.LENGTH_SHORT).show();
            updateSettingsStatuses();
            return;
        }
        requestPermissions(
                new String[]{
                        Manifest.permission.RECEIVE_SMS,
                        Manifest.permission.SEND_SMS
                },
                REQUEST_SMS_PERMISSIONS
        );
    }

    private boolean hasSmsPermissions() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || (checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED);
    }

    private void requestContactsPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || hasContactsPermission()) {
            Toast.makeText(this, "연락처 권한이 이미 허용되어 있어요.", Toast.LENGTH_SHORT).show();
            updateSettingsStatuses();
            return;
        }
        requestPermissions(
                new String[]{Manifest.permission.READ_CONTACTS},
                REQUEST_CONTACTS_PERMISSION
        );
    }

    private boolean hasContactsPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
    }

    private void updateContactsStatus(TextView target) {
        if (target == null) {
            return;
        }
        boolean ready = hasContactsPermission();
        target.setText(ready
                ? "준비 완료 · 전달 문자에 연락처 이름 표시"
                : "선택 권한 · 허용하지 않으면 번호로 표시");
        target.setTextColor(ready ? 0xFF258566 : 0xFF8C93A5);
    }

    private void updateSettingsStatuses() {
        updatePermissionStatus(settingsSmsStatus);
        updateContactsStatus(settingsContactsStatus);
        updateNotificationStatus(settingsNotificationStatus);
        if (settingsSummary == null) {
            return;
        }
        boolean smsReady = hasSmsPermissions();
        boolean notificationReady = !RuleStore.isNotificationCaptureEnabled(this)
                || NotificationAccessUtils.isEnabled(this);
        if (smsReady && notificationReady) {
            settingsSummary.setText("메시지 감지 준비가 완료됐어요.\n활성화한 설정은 화면이 꺼져 있어도 동작해요.");
        } else {
            settingsSummary.setText("아래 항목을 확인해 일반 SMS와\n채팅플러스 감지 준비를 완료해 주세요.");
        }
    }

    private int countActiveRules(List<Rule> rules) {
        int active = 0;
        for (Rule rule : rules) {
            if (rule.enabled) {
                active++;
            }
        }
        return active;
    }

    private void updateBulkStatus(TextView target, List<Rule> rules) {
        int active = countActiveRules(rules);
        boolean bulkOn = RuleStore.isEnabled(this);
        if (rules.isEmpty()) {
            target.setText("저장된 설정이 없어 일괄 변경할 항목이 없어요.");
        } else if (!bulkOn && active > 0) {
            target.setText("일괄 스위치는 꺼짐 · 개별 설정 " + active + "개는 정상 작동해요.");
        } else if (bulkOn) {
            target.setText("일괄 스위치는 켜짐 · 모든 설정을 한 번에 켠 상태예요.");
        } else {
            target.setText("일괄 스위치는 꺼짐 · 모든 설정이 중지된 상태예요.");
        }
    }

    private void pickContact(TagInputView target) {
        contactTarget = target;
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        try {
            startActivityForResult(intent, REQUEST_PICK_CONTACT);
        } catch (ActivityNotFoundException e) {
            contactTarget = null;
            Toast.makeText(this, "연락처 선택 화면을 열 수 없어요.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PICK_CONTACT) {
            return;
        }
        if (resultCode == RESULT_OK && data != null && data.getData() != null && contactTarget != null) {
            Uri contactUri = data.getData();
            ContentResolver resolver = getContentResolver();
            try (Cursor cursor = resolver.query(
                    contactUri,
                    new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null,
                    null,
                    null
            )) {
                if (cursor != null && cursor.moveToFirst()) {
                    int column = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    if (column >= 0) {
                        String number = cursor.getString(column);
                        if (contactTarget.addTag(number, true)) {
                            Toast.makeText(this, "연락처 번호를 추가했어요.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            } catch (RuntimeException e) {
                Toast.makeText(this, "연락처 번호를 불러오지 못했어요.", Toast.LENGTH_LONG).show();
            }
        }
        contactTarget = null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleImportIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateHeaderStatus();
        updateSettingsStatuses();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SMS_PERMISSIONS) {
            updateSettingsStatuses();
            Toast.makeText(
                    this,
                    hasSmsPermissions() ? "SMS 권한을 허용했어요." : "문자 수신·발송 권한이 모두 필요해요.",
                    Toast.LENGTH_LONG
            ).show();
        } else if (requestCode == REQUEST_CONTACTS_PERMISSION) {
            updateSettingsStatuses();
            Toast.makeText(
                    this,
                    hasContactsPermission() ? "연락처 권한을 허용했어요." : "연락처 이름 대신 번호가 표시돼요.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private String safeRuleName(Rule rule) {
        return rule.name == null || rule.name.trim().isEmpty() ? "문자배달 설정" : rule.name;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}