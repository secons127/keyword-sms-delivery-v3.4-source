package com.example.keywordsmsforwarder;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

public final class MessageDedupStore {
    private static final String PREFS_NAME = "settings";
    private static final String KEY_RECENT = "recent_message_claims_v3";
    private static final long WINDOW_MS = 45000L;
    private static final int MAX_RECORDS = 24;

    private MessageDedupStore() { }

    public static synchronized boolean claim(Context context, String sender, String body) {
        long now = System.currentTimeMillis();
        String full = hash(normalizedBody(body));
        String tail = hash(lastMeaningfulLine(body));
        String exact = hash(normalizedSender(sender) + "|" + normalizedBody(body));
        
        if (full.isEmpty()) {
            return false;
        }

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        JSONArray previous;
        try {
            previous = new JSONArray(prefs.getString(KEY_RECENT, "[]"));
        } catch (Exception e) {
            previous = new JSONArray();
        }

        JSONArray valid = new JSONArray();
        boolean isDuplicate = false;
        
        int len = previous.length();
        for (int i = 0; i < len; i++) {
            JSONObject item = previous.optJSONObject(i);
            if (item == null) {
                continue;
            }
            long time = item.optLong("time", 0L);
            if (now - time >= WINDOW_MS) {
                continue;
            }
            valid.put(item);
            
            String oldFull = item.optString("full");
            String oldTail = item.optString("tail");
            String oldExact = item.optString("exact");
            
            if (full.equals(oldFull)
                    || (!tail.isEmpty() && (tail.equals(oldTail) || tail.equals(oldFull)))
                    || (!oldTail.isEmpty() && full.equals(oldTail))
                    || exact.equals(oldExact)) {
                isDuplicate = true;
            }
        }

        if (!isDuplicate) {
            JSONObject current = new JSONObject();
            try {
                current.put("full", full);
                current.put("tail", tail);
                current.put("exact", exact);
                current.put("time", now);
                valid.put(current);
            } catch (Exception e) {
                return false;
            }
        }

        JSONArray trimmed = new JSONArray();
        int start = Math.max(0, valid.length() - MAX_RECORDS);
        int validLen = valid.length();
        for (int i = start; i < validLen; i++) {
            trimmed.put(valid.opt(i));
        }
        
        boolean saved = prefs.edit().putString(KEY_RECENT, trimmed.toString()).commit();
        return saved && !isDuplicate;
    }

    private static String normalizedSender(String sender) {
        if (sender == null) {
            return "";
        }
        return sender.replaceAll("[^0-9a-zA-Z가-힣]", "").toLowerCase(Locale.ROOT);
    }

    private static String normalizedBody(String body) {
        if (body == null) {
            return "";
        }
        String normalized = body.replace('\u00a0', ' ')
                .replace("\u200B", "")
                .replace("\u200C", "")
                .replace("\u200D", "")
                .replaceAll("\\s+", " ")
                .trim()
                .toLowerCase(Locale.ROOT);
                
        if (normalized.length() > 700) {
            return normalized.substring(0, 700);
        }
        return normalized;
    }

    private static String lastMeaningfulLine(String body) {
        if (body == null) {
            return "";
        }
        String[] lines = body.replace('\u00a0', ' ').split("\\r?\\n");
        for (int i = lines.length - 1; i >= 0; i--) {
            String val = normalizedBody(lines[i]);
            if (!val.isEmpty()
                    && !"새 메시지".equals(val)
                    && !"new message".equals(val)
                    && !"메시지가 도착했습니다".equals(val)) {
                return val;
            }
        }
        return normalizedBody(body);
    }

    private static String hash(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        return Integer.toHexString(value.hashCode());
    }
}