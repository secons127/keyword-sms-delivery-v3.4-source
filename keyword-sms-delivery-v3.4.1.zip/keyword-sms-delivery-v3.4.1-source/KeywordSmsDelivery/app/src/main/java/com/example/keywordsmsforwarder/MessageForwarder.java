package com.example.keywordsmsforwarder;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class MessageForwarder {
    private static final String TAG = "MessageForwarder";

    private MessageForwarder() {
    }

    public static void process(Context context, String sender, String body, String source) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    && context.checkSelfPermission(Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            String cleanSender = (sender == null || sender.trim().isEmpty()) ? "알 수 없음" : sender.trim();
            String cleanBody = body == null ? "" : body.trim();
            if (cleanBody.isEmpty()) {
                return;
            }
            
            List<Rule> rules = RuleStore.load(context);
            if (rules.isEmpty()) {
                return;
            }

            List<Rule> matchingRules = new ArrayList<>();
            for (Rule rule : rules) {
                if (rule.matches(cleanBody)) {
                    matchingRules.add(rule);
                }
            }
            
            if (matchingRules.isEmpty() || !MessageDedupStore.claim(context, cleanSender, cleanBody)) {
                return;
            }

            SmsManager smsManager = SmsManager.getDefault();
            Set<String> sentDestinations = new HashSet<>();

            for (Rule rule : matchingRules) {
                String senderLabel = resolveSenderLabel(context, cleanSender);
                String forwardedText = "[ " + senderLabel + " ]\n" + cleanBody;
                ArrayList<String> parts = smsManager.divideMessage(forwardedText);
                int sentForRule = 0;

                for (String destination : rule.destinations) {
                    String normalized = RuleStore.normalizePhone(destination);
                    if (normalized.isEmpty() || sentDestinations.contains(normalized)) {
                        continue;
                    }
                    sentDestinations.add(normalized);
                    sendNow(smsManager, normalized, forwardedText, parts);
                    sentForRule++;
                }

                if (sentForRule > 0) {
                    ForwardLogStore.add(
                            context,
                            rule,
                            cleanSender,
                            rule.matchedKeywords(cleanBody),
                            sentForRule,
                            safeSource(source)
                    );
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "forward msg error", e);
        }
    }

    private static String resolveSenderLabel(Context context, String sender) {
        if (sender == null || sender.trim().isEmpty()) {
            return "알 수 없음";
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && context.checkSelfPermission(Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            return sender;
        }

        Cursor cursor = null;
        try {
            Uri lookupUri = Uri.withAppendedPath(
                    ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                    Uri.encode(sender)
            );
            cursor = context.getContentResolver().query(
                    lookupUri,
                    new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME},
                    null,
                    null,
                    null
            );
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME);
                if (nameIndex >= 0) {
                    String displayName = cursor.getString(nameIndex);
                    if (displayName != null && !displayName.trim().isEmpty()) {
                        return displayName.trim();
                    }
                }
            }
        } catch (RuntimeException e) {
            Log.w(TAG, "contact search fail", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return sender;
    }

    private static String safeRuleName(Rule rule) {
        return (rule == null || rule.name == null || rule.name.trim().isEmpty()) ? "문자배달 설정" : rule.name;
    }

    private static String safeSource(String source) {
        return (source == null || source.trim().isEmpty()) ? "메시지" : source.trim();
    }

    private static void sendNow(
            SmsManager smsManager,
            String destination,
            String fullText,
            ArrayList<String> parts
    ) {
        if (parts.size() <= 1) {
            smsManager.sendTextMessage(destination, null, fullText, null, null);
        } else {
            smsManager.sendMultipartTextMessage(destination, null, parts, null, null);
        }
    }
}