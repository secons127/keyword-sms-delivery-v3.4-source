package com.example.keywordsmsforwarder;

import android.app.Notification;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.util.Log;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class MessageNotificationListener extends NotificationListenerService {
    private static final String TAG = "NotiListener";
    private static final Set<String> KNOWN_MESSAGE_PACKAGES = new HashSet<>(Arrays.asList(
            "com.samsung.android.messaging",
            "com.google.android.apps.messaging",
            "com.android.messaging",
            "com.android.mms",
            "com.lge.message",
            "com.sonyericsson.conversations",
            "com.htc.sense.mms"
    ));

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || sbn.getNotification() == null) {
                return;
            }
            if (!RuleStore.isNotificationCaptureEnabled(this) || !isMessagePackage(sbn.getPackageName())) {
                return;
            }

            Notification noti = sbn.getNotification();
            if ((noti.flags & Notification.FLAG_GROUP_SUMMARY) != 0) {
                return;
            }

            Bundle extras = noti.extras;
            if (extras == null) {
                return;
            }

            String sender = firstNonEmpty(
                    extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE),
                    extras.getCharSequence(Notification.EXTRA_TITLE),
                    extras.getCharSequence(Notification.EXTRA_TITLE_BIG)
            );
            String body = extractBody(extras);

            if (body.isEmpty() || isGenericNotification(body)) {
                return;
            }

            MessageForwarder.process(this, sender, body, sourceName(sbn.getPackageName()));
        } catch (Exception e) {
            Log.e(TAG, "noti handle error", e);
        }
    }

    private boolean isMessagePackage(String pkgName) {
        if (pkgName == null || pkgName.equals(getPackageName())) {
            return false;
        }
        if (KNOWN_MESSAGE_PACKAGES.contains(pkgName)) {
            return true;
        }
        String lower = pkgName.toLowerCase(Locale.ROOT);
        return lower.contains("messaging") || lower.endsWith(".mms") || lower.contains("message");
    }

    private String extractBody(Bundle extras) {
        String msgStyleText = extractMessagingStyle(extras.getParcelableArray(Notification.EXTRA_MESSAGES));
        if (!msgStyleText.isEmpty()) {
            return msgStyleText;
        }

        String bigText = charSequence(extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
        if (!bigText.isEmpty()) {
            return bigText;
        }

        CharSequence[] lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (lines != null && lines.length > 0) {
            for (int i = lines.length - 1; i >= 0; i--) {
                String val = charSequence(lines[i]);
                if (!val.isEmpty()) {
                    return val;
                }
            }
        }

        return charSequence(extras.getCharSequence(Notification.EXTRA_TEXT));
    }

    private String extractMessagingStyle(Parcelable[] messageBundles) {
        if (messageBundles == null || messageBundles.length == 0) {
            return "";
        }
        Parcelable latest = messageBundles[messageBundles.length - 1];
        if (!(latest instanceof Bundle)) {
            return "";
        }
        Bundle bundle = (Bundle) latest;
        return charSequence(bundle.getCharSequence("text"));
    }

    private String firstNonEmpty(CharSequence... values) {
        for (CharSequence val : values) {
            String str = charSequence(val);
            if (!str.isEmpty()) {
                return str;
            }
        }
        return "알 수 없음";
    }

    private String charSequence(CharSequence value) {
        return value == null ? "" : value.toString().trim();
    }

    private boolean isGenericNotification(String body) {
        String str = body.trim().toLowerCase(Locale.ROOT);
        return TextUtils.isEmpty(str)
                || "새 메시지".equals(str)
                || "new message".equals(str)
                || "메시지가 도착했습니다".equals(str);
    }

    private String sourceName(String pkgName) {
        if ("com.google.android.apps.messaging".equals(pkgName)) {
            return "Google 메시지 알림";
        }
        if ("com.samsung.android.messaging".equals(pkgName)) {
            return "삼성 메시지 알림";
        }
        return "메시지 앱 알림";
    }
}