package com.example.keywordsmsforwarder;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

public final class NotificationAccessUtils {
    private NotificationAccessUtils() {
    }

    public static boolean isEnabled(Context context) {
        String enabled = Settings.Secure.getString(
                context.getContentResolver(),
                "enabled_notification_listeners"
        );
        if (enabled == null || enabled.trim().isEmpty()) {
            return false;
        }
        
        String[] components = enabled.split(":");
        for (String str : components) {
            ComponentName comp = ComponentName.unflattenFromString(str);
            if (comp != null && context.getPackageName().equals(comp.getPackageName())) {
                return true;
            }
        }
        return false;
    }

    public static Intent settingsIntent() {
        return new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
    }
}