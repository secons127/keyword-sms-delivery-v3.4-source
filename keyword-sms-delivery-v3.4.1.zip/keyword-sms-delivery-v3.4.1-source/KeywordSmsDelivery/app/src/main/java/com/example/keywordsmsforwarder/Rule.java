package com.example.keywordsmsforwarder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Rule {
    public String id;
    public String name;
    public final List<String> destinations = new ArrayList<>();
    public final List<String> keywords = new ArrayList<>();
    public boolean enabled = true;
    public boolean matchAllKeywords = false;
    public long createdAt;
    public long updatedAt;

    public Rule() {
        this.id = String.valueOf(System.currentTimeMillis());
        this.createdAt = System.currentTimeMillis();
        this.updatedAt = this.createdAt;
    }

    public boolean matches(String body) {
        return enabled && matchesBody(body);
    }

    public boolean matchesBody(String body) {
        if (body == null || keywords.isEmpty()) {
            return false;
        }
        
        String targetBody = body.toLowerCase(Locale.ROOT);

        if (matchAllKeywords) {
            for (String kw : keywords) {
                String normalized = normalizeKeyword(kw);
                if (normalized.isEmpty() || !targetBody.contains(normalized)) {
                    return false;
                }
            }
            return true;
        }

        for (String kw : keywords) {
            String normalized = normalizeKeyword(kw);
            if (!normalized.isEmpty() && targetBody.contains(normalized)) {
                return true;
            }
        }
        return false;
    }

    public List<String> matchedKeywords(String body) {
        List<String> matched = new ArrayList<>();
        if (body == null) {
            return matched;
        }
        
        String targetBody = body.toLowerCase(Locale.ROOT);
        for (String kw : keywords) {
            String normalized = normalizeKeyword(kw);
            if (!normalized.isEmpty() && targetBody.contains(normalized)) {
                matched.add(kw);
            }
        }
        return matched;
    }

    private String normalizeKeyword(String keyword) {
        return keyword == null ? "" : keyword.trim().toLowerCase(Locale.ROOT);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("id", id);
        obj.put("name", name);
        obj.put("createdAt", createdAt);
        obj.put("updatedAt", updatedAt);
        obj.put("enabled", enabled);
        obj.put("matchAllKeywords", matchAllKeywords);

        JSONArray destArr = new JSONArray();
        for (String dest : destinations) {
            destArr.put(dest);
        }
        obj.put("destinations", destArr);

        JSONArray kwArr = new JSONArray();
        for (String kw : keywords) {
            kwArr.put(kw);
        }
        obj.put("keywords", kwArr);

        return obj;
    }

    public static Rule fromJson(JSONObject obj) throws JSONException {
        Rule rule = new Rule();
        rule.id = obj.optString("id", rule.id);
        rule.name = obj.optString("name", "문자배달 설정");
        rule.createdAt = obj.optLong("createdAt", System.currentTimeMillis());
        rule.updatedAt = obj.optLong("updatedAt", rule.createdAt);
        rule.enabled = obj.optBoolean("enabled", true);
        rule.matchAllKeywords = obj.optBoolean("matchAllKeywords", false);

        readArray(obj.optJSONArray("destinations"), rule.destinations);
        readArray(obj.optJSONArray("keywords"), rule.keywords);
        return rule;
    }

    private static void readArray(JSONArray array, List<String> target) {
        if (array == null) {
            return;
        }
        int len = array.length();
        for (int i = 0; i < len; i++) {
            String val = array.optString(i, "").trim();
            if (!val.isEmpty()) {
                target.add(val);
            }
        }
    }
}