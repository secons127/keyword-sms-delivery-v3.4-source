package com.example.keywordsmsforwarder;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class RuleStore {
    private static final String PREFS_NAME = "settings";
    private static final String KEY_RULES_V2 = "rules_v2";
    private static final String KEY_LEGACY_RULES = "rules";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_NOTIFICATION_CAPTURE = "notification_capture_enabled_v1";

    private RuleStore() {
    }

    public static List<Rule> load(Context context) {
        SharedPreferences prefs = getPrefs(context);
        String raw = prefs.getString(KEY_RULES_V2, "");
        if (raw != null && !raw.trim().isEmpty()) {
            return parseJson(raw);
        }

        List<Rule> rules = migrateLegacy(prefs);
        if (!rules.isEmpty()) {
            save(context, rules);
        }
        return rules;
    }

    public static void save(Context context, List<Rule> rules) {
        JSONArray arr = new JSONArray();
        for (Rule rule : rules) {
            try {
                arr.put(rule.toJson());
            } catch (JSONException e) {
                // skip invalid rule
            }
        }

        getPrefs(context).edit()
                .putString(KEY_RULES_V2, arr.toString())
                .putString(KEY_LEGACY_RULES, buildLegacyRules(rules))
                .apply();
    }

    public static boolean isEnabled(Context context) {
        return getPrefs(context).getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        getPrefs(context).edit()
                .putBoolean(KEY_ENABLED, enabled)
                .apply();
    }

    public static boolean isNotificationCaptureEnabled(Context context) {
        return getPrefs(context).getBoolean(KEY_NOTIFICATION_CAPTURE, true);
    }

    public static void setNotificationCaptureEnabled(Context context, boolean enabled) {
        getPrefs(context).edit()
                .putBoolean(KEY_NOTIFICATION_CAPTURE, enabled)
                .apply();
    }

    public static String exportJson(Context context) {
        JSONArray arr = new JSONArray();
        for (Rule rule : load(context)) {
            try {
                arr.put(rule.toJson());
            } catch (JSONException e) {
            }
        }
        return arr.toString();
    }

    public static List<Rule> parseJson(String raw) {
        List<Rule> rules = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) {
            return rules;
        }
        try {
            JSONArray arr = new JSONArray(raw);
            int len = arr.length();
            for (int i = 0; i < len; i++) {
                Rule rule = Rule.fromJson(arr.getJSONObject(i));
                if (!rule.destinations.isEmpty() && !rule.keywords.isEmpty()) {
                    rules.add(rule);
                }
            }
        } catch (JSONException e) {
        }
        return rules;
    }

    public static List<Rule> parseLegacyRules(String raw) {
        List<Rule> rules = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) {
            return rules;
        }
        
        String[] lines = raw.split("\\n");
        int idx = 1;
        for (String line : lines) {
            int sep = line.indexOf('|');
            if (sep <= 0) {
                continue;
            }
            String dest = Uri.decode(line.substring(0, sep)).trim();
            String kwBlock = Uri.decode(line.substring(sep + 1));
            if (dest.isEmpty() || kwBlock.trim().isEmpty()) {
                continue;
            }
            
            Rule rule = new Rule();
            rule.name = "가져온 설정 " + idx++;
            rule.destinations.add(normalizePhone(dest));
            
            for (String kw : kwBlock.split("[,;\\n]+")) {
                String val = kw.trim();
                if (!val.isEmpty()) {
                    rule.keywords.add(val);
                }
            }
            if (!rule.keywords.isEmpty()) {
                rules.add(rule);
            }
        }
        return rules;
    }

    private static List<Rule> migrateLegacy(SharedPreferences prefs) {
        List<Rule> rules = parseLegacyRules(prefs.getString(KEY_LEGACY_RULES, ""));
        if (!rules.isEmpty()) {
            return rules;
        }

        String destinations = prefs.getString("destination", "");
        String keywords = prefs.getString("keywords", "");
        if (destinations == null || keywords == null || keywords.trim().isEmpty()) {
            return rules;
        }
        
        Rule rule = new Rule();
        rule.name = "기존 문자배달 설정";
        for (String dest : destinations.split("[,;\\n]+")) {
            String normalized = normalizePhone(dest);
            if (!normalized.isEmpty()) {
                rule.destinations.add(normalized);
            }
        }
        for (String kw : keywords.split("[,;\\n]+")) {
            String val = kw.trim();
            if (!val.isEmpty()) {
                rule.keywords.add(val);
            }
        }
        if (!rule.destinations.isEmpty() && !rule.keywords.isEmpty()) {
            rules.add(rule);
        }
        return rules;
    }

    private static String buildLegacyRules(List<Rule> rules) {
        StringBuilder sb = new StringBuilder();
        for (Rule rule : rules) {
            if (!rule.enabled) {
                continue;
            }
            String kwBlock = join(rule.keywords, ",");
            for (String dest : rule.destinations) {
                if (sb.length() > 0) {
                    sb.append('\n');
                }
                sb.append(Uri.encode(dest));
                sb.append('|');
                sb.append(Uri.encode(kwBlock));
            }
        }
        return sb.toString();
    }

    public static String normalizePhone(String value) {
        if (value == null) {
            return "";
        }
        String normalized = value.trim().replaceAll("[-()\\s]", "");
        if (normalized.startsWith("+82") && normalized.length() > 3) {
            normalized = "0" + normalized.substring(3);
        } else if (normalized.startsWith("82") && normalized.length() >= 11) {
            normalized = "0" + normalized.substring(2);
        }
        return normalized;
    }

    public static String normalizeAddress(String value) {
        if (value == null) {
            return "";
        }
        String str = value.trim();
        if (str.matches("[+0-9()\\-\\s]+")) {
            return normalizePhone(str);
        }
        return str.replaceAll("\\s", "").toLowerCase(Locale.ROOT);
    }

    public static String join(List<String> values, String separator) {
        StringBuilder sb = new StringBuilder();
        for (String val : values) {
            if (sb.length() > 0) {
                sb.append(separator);
            }
            sb.append(val);
        }
        return sb.toString();
    }

    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
}