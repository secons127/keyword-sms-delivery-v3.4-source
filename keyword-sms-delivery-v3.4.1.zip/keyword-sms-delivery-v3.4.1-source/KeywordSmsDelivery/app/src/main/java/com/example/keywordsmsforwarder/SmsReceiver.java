package com.example.keywordsmsforwarder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;

public class SmsReceiver extends BroadcastReceiver {
    private static final String TAG = "SmsReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (intent == null || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) {
                return;
            }

            SmsMessage[] msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent);
            if (msgs == null || msgs.length == 0) {
                return;
            }

            String sender = "알 수 없음";
            StringBuilder sb = new StringBuilder();
            
            int len = msgs.length;
            for (int i = 0; i < len; i++) {
                SmsMessage msg = msgs[i];
                if (i == 0 && msg.getOriginatingAddress() != null) {
                    sender = msg.getOriginatingAddress();
                }
                if (msg.getMessageBody() != null) {
                    sb.append(msg.getMessageBody());
                }
            }

            MessageForwarder.process(context, sender, sb.toString(), "일반 SMS");
        } catch (Exception e) {
            Log.e(TAG, "sms recv error", e);
        }
    }
}