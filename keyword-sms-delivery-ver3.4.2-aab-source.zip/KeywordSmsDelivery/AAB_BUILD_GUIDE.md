# AAB 빌드 방법

이 프로젝트는 Android App Bundle(AAB) 생성용으로 다음 값이 적용되어 있습니다.

- compileSdk: 35
- targetSdk: 35
- versionCode: 12
- versionName: 3.4.2

## Android Studio에서 서명된 AAB 만들기

1. 프로젝트의 `KeywordSmsDelivery` 폴더를 Android Studio로 엽니다.
2. Gradle Sync가 끝날 때까지 기다립니다.
3. 상단 메뉴에서 `Build > Generate Signed Bundle / APK`를 선택합니다.
4. `Android App Bundle`을 선택하고 `Next`를 누릅니다.
5. 기존 키가 있으면 해당 `.jks` 파일을 선택합니다.
6. 키가 없으면 `Create new`를 눌러 새 키스토어를 만듭니다.
7. Build Variant는 `release`를 선택합니다.
8. `Create` 또는 `Finish`를 누릅니다.

생성 위치는 일반적으로 다음과 같습니다.

`app/build/outputs/bundle/release/app-release.aab`

## 명령어로 디버그 AAB 만들기

Windows:

`gradlew.bat bundleDebug`

macOS/Linux:

`./gradlew bundleDebug`

생성 위치:

`app/build/outputs/bundle/debug/app-debug.aab`

## 업데이트 시 주의사항

- 다음 버전을 올릴 때마다 `versionCode`를 13, 14처럼 증가시켜야 합니다.
- 기존 앱을 삭제하지 않고 업데이트하려면 이전 APK/AAB와 동일한 applicationId와 동일한 서명 키를 사용해야 합니다.
- `.jks`, 키스토어 비밀번호, alias 비밀번호를 잃어버리지 마세요.
- 키스토어 파일과 비밀번호 파일은 GitHub에 올리지 마세요.
