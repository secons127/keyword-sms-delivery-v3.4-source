# 3.4.2

- Android App Bundle(AAB) 빌드 준비
- targetSdk 35 적용
- versionCode 12 / versionName 3.4.2 적용
- 서명 파일 Git 제외 설정 추가

# 변경 사항

- release 난독화 후 XML 커스텀 입력 화면이 실행 즉시 종료되던 문제 수정
- 일반 SMS와 메시지 앱 알림이 같은 문자를 감지해도 한 번만 전달하도록 중복 잠금 강화
- 알림의 누적 문장 대신 가장 최근 메시지를 우선 감지
- 발신자 조건 입력 및 필터 로직 제거
- 설정 화면 하단 제작자 표시 추가
- 공식 APK 서명 확인과 release 코드 난독화 적용
